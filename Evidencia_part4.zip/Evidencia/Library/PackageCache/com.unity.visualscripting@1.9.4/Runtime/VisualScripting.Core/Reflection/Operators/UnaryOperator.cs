namespace Unity.VisualScripting
{
    public enum UnaryOperator
    {
        LogicalNegation,
        NumericNegation,
        Increment,
        Decrement,
        Plus
    }
}
